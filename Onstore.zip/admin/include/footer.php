	<div class="footer">
		<div class="container">
			 

			<b class="copyright">&copy; 2024 OnStore </b> All rights reserved.
		</div>
	</div>